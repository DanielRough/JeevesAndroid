# JeevesAndroid
Android companion to the Jeeves project

THIS is the newest version of the Jeeves Android app, now available on the Google Play Store from <a href="https://play.google.com/store/apps/details?id=com.jeeves">this link</a>.
The only real change from the 'master' branch original version of Jeeves is the ability for participants to sign up to a study via a URL.
