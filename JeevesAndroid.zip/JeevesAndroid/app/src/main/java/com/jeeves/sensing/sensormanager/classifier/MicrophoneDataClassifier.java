/* **************************************************
 Copyright (c) 2012, University of Cambridge
 Neal Lathia, neal.lathia@cl.cam.ac.uk
 Kiran Rachuri, kiran.rachuri@cl.cam.ac.uk

This library was developed as part of the EPSRC Ubhave (Ubiquitous and
Social Computing for Positive Behaviour Change) Project. For more
information, please visit http://www.emotionsense.org

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 ************************************************** */

package com.jeeves.sensing.sensormanager.classifier;

import com.jeeves.sensing.sensormanager.config.MicrophoneConfig;
import com.jeeves.sensing.sensormanager.config.SensorConfig;
import com.jeeves.sensing.sensormanager.data.MicrophoneData;
import com.jeeves.sensing.sensormanager.data.SensorData;

public class MicrophoneDataClassifier implements SensorDataClassifier
{
	private static boolean lastStatus = false;
	@Override
	public boolean isInteresting(final SensorData sensorData, final SensorConfig sensorConfig, String value, boolean isTrigger)
	{
		MicrophoneData data = (MicrophoneData) sensorData;

		if (isSilent(data.getAmplitudeArray(), (Integer) sensorConfig.getParameter(MicrophoneConfig.SOUND_THRESHOLD)))
		{
			stringStatus = "Quiet";

			if(value.equals("Quiet") && (isTrigger == false || lastStatus == true)){
					lastStatus = false;
					return true;

			}
			else {
				lastStatus = true;
				return false;
			}
			}
		else
		{
			stringStatus = "Noisy";

			lastStatus = true;
			if(value.equals("Quiet") && (isTrigger == false || lastStatus == false)) {
					lastStatus = false;
					return false;
			}
			else {
				lastStatus = true;
				return true;
			}
		}
	}

	private boolean isSilent(int[] amplitudeData, int soundThreshold)
	{
		double avgAmplitude = 0;

		for (int aValue : amplitudeData)
		{
			avgAmplitude += aValue;
		}
		avgAmplitude = avgAmplitude / (double)amplitudeData.length;
        return !(avgAmplitude > soundThreshold);
	}
	private String stringStatus;

	@Override
	public String getClassification(SensorData sensorData, SensorConfig sensorConfig) {
		isInteresting(sensorData,sensorConfig,"",false);
		return stringStatus;
	}
}
