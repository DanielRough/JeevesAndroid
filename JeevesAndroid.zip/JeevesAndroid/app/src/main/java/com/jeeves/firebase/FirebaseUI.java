package com.jeeves.firebase;

import com.google.firebase.database.IgnoreExtraProperties;

/**
 * Created by Daniel on 12/07/16.
 */
@IgnoreExtraProperties
public class FirebaseUI {

   // private String id;
    private String name;
    private String text;
    //private String type;
   // private long xPos;
   // private long yPos;
//private String description;
//
//   public String getid() {
//        return id;
//
//    }
//
    public String getname() {
        return name;
    }

    public String gettext() {
        return text;
    }

//    public String gettype() {
//        return type;
//    }
//
//    public long getxPos() {
//        return xPos;
//    }
//
//    public long getyPos() {
//        return yPos;
//    }
//
//    public String getdescription(){ return description; }

}
